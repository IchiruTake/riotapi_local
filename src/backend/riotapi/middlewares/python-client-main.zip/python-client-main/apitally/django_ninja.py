from apitally.django import ApitallyMiddleware


__all__ = ["ApitallyMiddleware"]
